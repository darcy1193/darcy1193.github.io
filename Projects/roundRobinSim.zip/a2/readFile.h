#ifndef READFILE_H
#define READFILE_H
#include "a2.h"

void readFile(char* fileName, int size, process processArray[]);
void getProcessArray(process processArray[], int size);

#endif
