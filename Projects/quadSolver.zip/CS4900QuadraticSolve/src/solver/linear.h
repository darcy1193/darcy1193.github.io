#ifndef LINEAR_H
#define LINEAR_H

#include "../misc.h"

intercepts linear(float b,float c);

#endif //LINEAR_H
