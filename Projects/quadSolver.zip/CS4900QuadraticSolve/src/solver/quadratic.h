#ifndef QUADRATIC_H
#define QUADRATIC_H

#include "../misc.h"

intercepts quadratic(float a,float b,float c);

#endif //QUADRATIC_H
