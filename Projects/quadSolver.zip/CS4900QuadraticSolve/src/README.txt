Directory containing all the source files.

To make the program, type 'make' or 'make quadsolve'.
The name of the program will be 'quadsolve'.

To make the testing program, type 'make' or 'make quadtest'.
The name of the program will be 'quadtest'.
