#ifndef LIBRARIES_H
#define LIBRARIES_H

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <errno.h>

#endif //LIBRARIES_H
