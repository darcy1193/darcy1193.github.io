Notes to self: (DMD)

  + Create t1 -> quadratic.c, linear.c *MOCK OBJECT
  + Create t2 -> parsing.c 	       *MOCK OBJECT
  ~ Create t3 -> ieee_isquad, ieee_feq *MOCK OBJECT
  - Create validate tests for t3, feq is done.  Add mock objects to t-files.