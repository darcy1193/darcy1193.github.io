
//Prototypes for mock object
void mock_setup_feq(float tb, float tc, float tepsilon, bool tfeqAns);
int mock_check_feq(int *tcount, float *tb, float *tc);
void mock_teardown_feq();

