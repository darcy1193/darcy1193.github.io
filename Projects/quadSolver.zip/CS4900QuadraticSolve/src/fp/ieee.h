#ifndef IEEE_H
#define IEEE_H

#include "../misc.h"

bool feq(float a,float b);
bool isquad(float a,float b,float c);

#endif //IEEE_H
