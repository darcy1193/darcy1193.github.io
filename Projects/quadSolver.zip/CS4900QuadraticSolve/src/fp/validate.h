#ifndef VALIDATE_H
#define VALIDATE_H

#include "../misc.h"

float quadfunc(float a,float c,float b,float x);
bool validate(float a,float b,float c,intercepts x);

#endif //VALIDATE_H
