# CS4900QuadraticSolve
Solve the quadratic formula given inputs 'a', 'b', and 'c'.  
The file "LICENSE.txt" contains copyright information.
The file "RETVALS.txt" contains information about the program's return values.
