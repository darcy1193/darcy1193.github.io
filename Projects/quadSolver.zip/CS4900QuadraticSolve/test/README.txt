This directory contains all files used for testing. To run all tests, just type 'make' or 'make all'.
