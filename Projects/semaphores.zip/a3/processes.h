

void Process (sem_t * screen, sem_t * keyboard, int index);
int getSemaphores (sem_t *screen, sem_t *keyboard, int index);
