#ifndef __DTC_H__
#define __DTC_H__

#include <msp430.h>

void initialize_dtc(unsigned int, unsigned int*);

#endif

